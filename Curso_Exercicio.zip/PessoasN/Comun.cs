﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PessoasN
{
    public abstract class Comun
    {
        private int _ID = 0;
        public int ID
        {
            get { return _ID; }
            set { _ID = value; }
        }
        
        public DateTime DtInclusao { get; set; }
        public DateTime DtAlteracao { get; set; }
        public DateTime DtExclusao { get; set; }

        protected virtual bool Salvar(out string Erro)
        {
            Erro = "";

            if (this.ID == 0)
                //inclusão
                this.DtInclusao = DateTime.Now;

            else
                //Alteração
                this.SetaCamposAlteracao();

            return true;

        }
        protected virtual bool Excluir(out string Erro)
        {
            Erro = "";

            this.DtExclusao = DateTime.Now;

            return true;

        }

        protected void SetaCamposAlteracao()
        {
            //Alteração
            this.DtAlteracao = DateTime.Now;

        }

    }
}
